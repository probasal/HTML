import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GstinListPage } from './gstin-list';

@NgModule({
  declarations: [
    GstinListPage,
  ],
  imports: [
    IonicPageModule.forChild(GstinListPage),
  ],
})
export class GstinListPageModule {}
