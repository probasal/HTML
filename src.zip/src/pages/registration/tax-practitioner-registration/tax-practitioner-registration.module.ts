import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TaxPractitionerRegistrationPage } from './tax-practitioner-registration';

@NgModule({
  declarations: [
    TaxPractitionerRegistrationPage,
  ],
  imports: [
    IonicPageModule.forChild(TaxPractitionerRegistrationPage),
  ],
})
export class TaxPractitionerRegistrationPageModule {}
