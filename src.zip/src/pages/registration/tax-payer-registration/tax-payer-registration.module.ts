import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TaxPayerRegistrationPage } from './tax-payer-registration';

@NgModule({
  declarations: [
    TaxPayerRegistrationPage,
  ],
  imports: [
    IonicPageModule.forChild(TaxPayerRegistrationPage),
  ],
})
export class TaxPayerRegistrationPageModule {}
