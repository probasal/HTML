import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GskRegistrationPage } from './gsk-registration';

@NgModule({
  declarations: [
    GskRegistrationPage,
  ],
  imports: [
    IonicPageModule.forChild(GskRegistrationPage),
  ],
})
export class GskRegistrationPageModule {}
