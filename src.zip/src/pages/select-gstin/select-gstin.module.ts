import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SelectGstinPage } from './select-gstin';

@NgModule({
  declarations: [
    SelectGstinPage,
  ],
  imports: [
    IonicPageModule.forChild(SelectGstinPage),
  ],
})
export class SelectGstinPageModule {}
