import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AccountsDashboardPage } from './accounts-dashboard';

@NgModule({
  declarations: [
    AccountsDashboardPage,
  ],
  imports: [
    IonicPageModule.forChild(AccountsDashboardPage),
  ],
})
export class AccountsDashboardPageModule {}
