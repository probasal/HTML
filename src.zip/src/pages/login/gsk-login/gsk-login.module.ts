import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GskLoginPage } from './gsk-login';

@NgModule({
  declarations: [
    GskLoginPage,
  ],
  imports: [
    IonicPageModule.forChild(GskLoginPage),
  ],
})
export class GskLoginPageModule {}
