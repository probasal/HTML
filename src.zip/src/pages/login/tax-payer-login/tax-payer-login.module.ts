import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TaxPayerLoginPage } from './tax-payer-login';

@NgModule({
  declarations: [
    TaxPayerLoginPage,
  ],
  imports: [
    IonicPageModule.forChild(TaxPayerLoginPage),
  ],
})
export class TaxPayerLoginPageModule {}
