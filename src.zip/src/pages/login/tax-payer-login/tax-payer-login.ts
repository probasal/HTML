import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';

import { OtpComponent } from '../../../components/otp/otp';

/**
 * Generated class for the TaxPayerLoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-tax-payer-login',
  templateUrl: 'tax-payer-login.html',
})
export class TaxPayerLoginPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TaxPayerLoginPage');
  }


  presentProfileModal() {
    const data = {
      userId : 8675309,
      name: 'shailendra'
    }
    let profileModal = this.modalCtrl.create(OtpComponent, { getdata : data });
    profileModal.present();
  }

}
