import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TaxPractitionerLoginPage } from './tax-practitioner-login';

@NgModule({
  declarations: [
    TaxPractitionerLoginPage,
  ],
  imports: [
    IonicPageModule.forChild(TaxPractitionerLoginPage),
  ],
})
export class TaxPractitionerLoginPageModule {}
