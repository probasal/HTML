import { NgModule } from '@angular/core';
import { OtpComponent } from './otp/otp';
@NgModule({
	declarations: [OtpComponent],
	imports: [],
	exports: [OtpComponent]
})
export class ComponentsModule {}
