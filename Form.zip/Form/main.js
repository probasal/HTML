$('document').ready(function(){
    $(".sign-option1 li").click(function(){
        $('.signin').hide();
        $('.joinus').hide();
        $(".sign-option1 li").removeClass('active');
        var myform = $(this).data('myfrm');
        $(this).addClass('active');
        $('.'+ myform).show(); 
        $('.'+ myform).addClass('animated zoomInUp'); 
        // zoomIn fadeIn
    });
})