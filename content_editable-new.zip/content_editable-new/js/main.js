$('document').ready(function(){

    var counterBox = $('.count span');
    var msgBox = $('.post_msg');
    
    msgBox.on("keypress", function (e) {
        var wordscount = $(this).text().length;
        var str = $(this).text();
        if (wordscount >= 160) {
            e.preventDefault();
            return false;
        }
    });

    msgBox.bind('paste', function (e){
        $(e.target).keyup(getInput);
    });

    msgBox.on("keyup keydown", function (e) {
        var wordscount = $(this).text().length;
        counterBox.html(wordscount);
    });

        
    function getInput(e){
        var str = $(this).text();
        var res = str.substr(0, 160);
        msgBox.text(res);
        $(e.target).unbind('keyup');
    }

})