$('document').ready(function(){
    
    var counterBox = $('.count span');
    var msgBox = $('.post_msg');

    counterBox.html(msgBox.text().length)

    msgBox.on("keypress paste", function (e) {
    var wordscount = $(this).text().length;
    if (wordscount >= 160) {
        e.preventDefault();
        return false;
    }
    });

    msgBox.on("keyup keydown", function (e) {
        var wordscount = $(this).text().length;
        counterBox.html(wordscount);
    });

})